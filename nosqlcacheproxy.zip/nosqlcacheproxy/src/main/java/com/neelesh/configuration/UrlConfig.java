package com.neelesh.configuration;

public class UrlConfig {
	private String url ; 
	private String forwardurl ; 
	private String collectionname ; 
	private String prefix ; 
	private String fieldlist ;
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getForwardurl() {
		return forwardurl;
	}
	public void setForwardurl(String forwardurl) {
		this.forwardurl = forwardurl;
	}
	public String getCollectionname() {
		return collectionname;
	}
	public void setCollectionname(String collectionname) {
		this.collectionname = collectionname;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getFieldlist() {
		return fieldlist;
	}
	public void setFieldlist(String fieldlist) {
		this.fieldlist = fieldlist;
	} 
	

}

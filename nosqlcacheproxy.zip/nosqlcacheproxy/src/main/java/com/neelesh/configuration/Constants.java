package com.neelesh.configuration;

public class Constants {

	
	//public static final String MONGO_DB_HOST = "neelesh.zapto.org" ;
	public static final String MONGO_DB_HOST = "localhost" ;
	//public static final String MONGO_DB_HOST = "192.168.88.252" ;
	public static final String MONGO_DB_NAME = "avalon" ;
	public static final String MESSAGE = "message" ;
	public static final String MESSAGE_TYPE = "message_type" ;
	public static final String MESSAGE_TYPE_ERROR_CSS_CLASS = "error" ;
	public static final String MESSAGE_TYPE_INFO_CSS_CLASS = "info" ;
	public static final String MESSAGE_CSSCLASS = "cssclass" ;
	

}
